class DocumentoAPI {

  async show(id) {
    let response = await fetch(`${BASE_URL}/api/v1/documento/${id}`, {
      method: 'GET'
    });
    let json = await response.json();

    return json;
  }

  async create(datos) {
    let response = await fetch(`${BASE_URL}/api/v1/documento`, {
      method: 'POST',
      body: datos
    });
    let json = await response.json();

    return json;
  }

  async update(id, datos) {
    let response = await fetch(`${BASE_URL}/api/v1/documento/${id}/update`, {
      method: 'POST',
      body: datos
    });
    let json = await response.json();

    return json;
  }

  async delete(id) {
    let response = await fetch(`${BASE_URL}/api/v1/documento/${id}`, {
      method: 'DELETE'
    });
    let json = await response.json();

    return json;
  }
}