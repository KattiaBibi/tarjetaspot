<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    body {
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      overflow: hidden;
    }

    iframe {
      border-radius: 10px;
      height: 700px;
      width: 500px;
    }
  </style>
</head>

<body>

  <iframe src="http://tarjetaspot.local/usuario/ver-tarjeta/2" frameborder="0" id="myIframe"></iframe>

</body>

</html>